<?php

/**
 * Charity - Custom Post Type
 *
 * @package     charity
 * @version     v.1.0
 */
require_once 'causes.php';
require_once 'gallery.php';
require_once 'project.php';
require_once 'portfolio.php';
require_once 'our-works.php';
require_once 'our-mission.php';
require_once 'help-several-way.php';
require_once 'faq.php';
require_once 'testimonial.php';


