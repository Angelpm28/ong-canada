<?php

/**
 * Charity - Shortcodes
 *
 * @package     charity
 * @version     v.1.0
 */

require_once 'general.php';
require_once 'causes_donation_summary.php';
require_once 'causes_donation_bullet_content.php';

require_once 'charity-typography.php';
require_once 'charity-tabs.php';
require_once 'charity-toggle.php';
